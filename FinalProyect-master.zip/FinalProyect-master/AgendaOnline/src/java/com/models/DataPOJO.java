/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.models;

public class DataPOJO {
   
    private String materia;
    private String deber;
    private String fecha;
    
    public String getMateria() {
        return materia;
    }
    public void setMateria(String materia) {
        this.materia = materia;
    }

    
    public String getDeber() {
        return deber;
    }

    
    public void setDeber(String deber) {
        this.deber = deber;
    }

    
    public String getFecha() {
        return fecha;
    }

 
    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
}
